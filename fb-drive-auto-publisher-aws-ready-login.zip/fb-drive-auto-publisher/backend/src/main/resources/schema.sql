CREATE TABLE IF NOT EXISTS google_drive_config (
  id BIGINT PRIMARY KEY DEFAULT 1,
  client_id TEXT,
  client_secret TEXT,
  folder_id TEXT,
  access_token TEXT,
  refresh_token TEXT,
  token_expires_at TIMESTAMP,
  connected_email TEXT,
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS facebook_pages (
  id BIGSERIAL PRIMARY KEY,
  page_id TEXT NOT NULL UNIQUE,
  page_name TEXT,
  page_token TEXT NOT NULL,
  enabled BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS scheduler_config (
  id BIGINT PRIMARY KEY DEFAULT 1,
  reels_enabled BOOLEAN DEFAULT FALSE,
  videos_enabled BOOLEAN DEFAULT FALSE,
  interval_minutes INT DEFAULT 60,
  caption TEXT DEFAULT '',
  last_reels_run_at TIMESTAMP,
  last_videos_run_at TIMESTAMP,
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS publish_history (
  id BIGSERIAL PRIMARY KEY,
  drive_file_id TEXT NOT NULL,
  drive_file_name TEXT,
  page_id TEXT NOT NULL,
  publish_type TEXT NOT NULL,
  facebook_video_id TEXT,
  facebook_post_id TEXT,
  status TEXT NOT NULL,
  error_message TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE (drive_file_id, page_id, publish_type)
);

INSERT INTO google_drive_config(id) VALUES (1) ON CONFLICT (id) DO NOTHING;
INSERT INTO scheduler_config(id) VALUES (1) ON CONFLICT (id) DO NOTHING;


CREATE TABLE IF NOT EXISTS app_users (
  id BIGSERIAL PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  full_name TEXT,
  role TEXT NOT NULL DEFAULT 'ROLE_ADMIN',
  enabled BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

INSERT INTO app_users(username,password_hash,full_name,role,enabled)
VALUES ('admin', '$2y$10$pJQJZ1QRdLNMZP3G7Op9LeqLyTyCjq0xF1JMa.LYGbb/TQuy84mYq', 'Administrator', 'ROLE_ADMIN', true)
ON CONFLICT (username) DO NOTHING;
