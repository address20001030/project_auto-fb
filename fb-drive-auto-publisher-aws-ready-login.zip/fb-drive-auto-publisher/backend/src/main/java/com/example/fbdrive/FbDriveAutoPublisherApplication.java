
package com.example.fbdrive;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.http.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.filter.OncePerRequestFilter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.security.MessageDigest;

import java.io.*;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.*;
import java.util.Base64;

@SpringBootApplication
@EnableScheduling
public class FbDriveAutoPublisherApplication {
  public static void main(String[] args) { SpringApplication.run(FbDriveAutoPublisherApplication.class, args); }
  @Bean RestTemplate restTemplate(RestTemplateBuilder b) { return b.build(); }
  @Bean PasswordEncoder passwordEncoder() { return new BCryptPasswordEncoder(); }
}

record GoogleConfig(String clientId, String clientSecret, String folderId, String connectedEmail, boolean connected) {}
record PageReq(String pageId, String pageName, String pageToken, Boolean enabled) {}
record SchedulerReq(Boolean reelsEnabled, Boolean videosEnabled, Integer intervalMinutes, String caption) {}
record ManualReq(String pageId, String fileId, String caption) {}
record LoginReq(String username, String password) {}
record ChangePasswordReq(String oldPassword, String newPassword) {}
record ApiResp(boolean ok, Object data, String error) {
  static ApiResp ok(Object d){return new ApiResp(true,d,null);} static ApiResp err(String e){return new ApiResp(false,null,e);} }



@RestControllerAdvice
class GlobalExceptionHandler {
  @ExceptionHandler(Exception.class)
  ResponseEntity<ApiResp> handle(Exception e){ return ResponseEntity.badRequest().body(ApiResp.err(e.getMessage())); }
}

@Configuration
class SecurityConfig {
  private final JwtAuthFilter jwt;
  SecurityConfig(JwtAuthFilter jwt){this.jwt=jwt;}
  @Bean SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    http.csrf(csrf -> csrf.disable())
      .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
      .authorizeHttpRequests(auth -> auth
        .requestMatchers("/api/auth/login", "/api/health", "/api/google/callback").permitAll()
        .requestMatchers("/api/**").authenticated()
        .anyRequest().permitAll()
      )
      .addFilterBefore(jwt, UsernamePasswordAuthenticationFilter.class);
    return http.build();
  }
}

@Service
class JwtService {
  @Value("${app.jwt-secret:change-this-secret-in-production-please}") String secret;
  private static final ObjectMapper MAPPER = new ObjectMapper();
  String createToken(String username, String role){
    try {
      long now = Instant.now().getEpochSecond();
      Map<String,Object> header = Map.of("alg","HS256","typ","JWT");
      Map<String,Object> payload = new LinkedHashMap<>();
      payload.put("sub", username); payload.put("role", role); payload.put("iat", now); payload.put("exp", now + 86400);
      String h = b64(MAPPER.writeValueAsBytes(header));
      String p = b64(MAPPER.writeValueAsBytes(payload));
      return h + "." + p + "." + sign(h + "." + p);
    } catch(Exception e){ throw new RuntimeException(e); }
  }
  Map<String,Object> verify(String token){
    try{
      String[] parts = token.split("\\."); if(parts.length != 3) throw new RuntimeException("Token sai định dạng");
      String expected = sign(parts[0] + "." + parts[1]); if(!MessageDigest.isEqual(expected.getBytes(StandardCharsets.UTF_8), parts[2].getBytes(StandardCharsets.UTF_8))) throw new RuntimeException("Token sai chữ ký");
      Map<String,Object> payload = MAPPER.readValue(Base64.getUrlDecoder().decode(parts[1]), new TypeReference<>(){});
      Number exp = (Number) payload.get("exp"); if(exp == null || exp.longValue() < Instant.now().getEpochSecond()) throw new RuntimeException("Token hết hạn");
      return payload;
    }catch(Exception e){ throw new RuntimeException("Token không hợp lệ"); }
  }
  private String sign(String data) throws Exception { Mac mac = Mac.getInstance("HmacSHA256"); mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256")); return b64(mac.doFinal(data.getBytes(StandardCharsets.UTF_8))); }
  private static String b64(byte[] b){ return Base64.getUrlEncoder().withoutPadding().encodeToString(b); }
}

@Service
class UserService {
  private final JdbcTemplate jdbc; private final PasswordEncoder encoder;
  UserService(JdbcTemplate jdbc, PasswordEncoder encoder){this.jdbc=jdbc;this.encoder=encoder;}
  Map<String,Object> findActive(String username){
    List<Map<String,Object>> rows = jdbc.queryForList("SELECT * FROM app_users WHERE username=? AND enabled=true", username);
    if(rows.isEmpty()) throw new RuntimeException("Sai tài khoản hoặc mật khẩu"); return rows.get(0);
  }
  void changePassword(String username, String oldPass, String newPass){
    Map<String,Object> u = findActive(username);
    if(!encoder.matches(oldPass, (String)u.get("password_hash"))) throw new RuntimeException("Mật khẩu cũ không đúng");
    if(newPass == null || newPass.length() < 8) throw new RuntimeException("Mật khẩu mới phải từ 8 ký tự");
    jdbc.update("UPDATE app_users SET password_hash=?, updated_at=NOW() WHERE username=?", encoder.encode(newPass), username);
  }
}

@Service
class JwtAuthFilter extends OncePerRequestFilter {
  private final JwtService jwt;
  JwtAuthFilter(JwtService jwt){this.jwt=jwt;}
  @Override protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws ServletException, IOException {
    String h = request.getHeader("Authorization");
    if(h != null && h.startsWith("Bearer ")){
      try{
        Map<String,Object> p = jwt.verify(h.substring(7));
        String username = (String)p.get("sub"); String role = String.valueOf(p.getOrDefault("role", "ROLE_ADMIN"));
        var auth = new UsernamePasswordAuthenticationToken(username, null, List.of(new SimpleGrantedAuthority(role)));
        org.springframework.security.core.context.SecurityContextHolder.getContext().setAuthentication(auth);
      }catch(Exception ignored){}
    }
    chain.doFilter(request, response);
  }
}

@RestController
@RequestMapping("/api/auth")
class AuthController {
  private final UserService users; private final PasswordEncoder encoder; private final JwtService jwt;
  AuthController(UserService users, PasswordEncoder encoder, JwtService jwt){this.users=users;this.encoder=encoder;this.jwt=jwt;}
  @PostMapping("/login") ApiResp login(@RequestBody LoginReq req){
    Map<String,Object> u = users.findActive(req.username());
    if(!encoder.matches(req.password(), (String)u.get("password_hash"))) throw new RuntimeException("Sai tài khoản hoặc mật khẩu");
    return ApiResp.ok(Map.of("accessToken", jwt.createToken((String)u.get("username"), (String)u.get("role")), "username", u.get("username"), "role", u.get("role"), "expiresIn", 86400));
  }
  @GetMapping("/me") ApiResp me(org.springframework.security.core.Authentication auth){ return ApiResp.ok(Map.of("username", auth.getName())); }
  @PostMapping("/change-password") ApiResp change(@RequestBody ChangePasswordReq req, org.springframework.security.core.Authentication auth){ users.changePassword(auth.getName(), req.oldPassword(), req.newPassword()); return ApiResp.ok("changed"); }
}

@RestController
@RequestMapping("/api")
class ApiController {
  private final JdbcTemplate jdbc; private final GoogleDriveService drive; private final FacebookService fb; private final PublishService pub;
  ApiController(JdbcTemplate jdbc, GoogleDriveService drive, FacebookService fb, PublishService pub){this.jdbc=jdbc;this.drive=drive;this.fb=fb;this.pub=pub;}

  @GetMapping("/health") Map<String,Object> health(){return Map.of("status","UP", "time", Instant.now().toString());}

  @GetMapping("/google/config") GoogleConfig googleConfig(){ return drive.getConfigPublic(); }
  @PostMapping("/google/config") ApiResp saveGoogle(@RequestBody Map<String,String> body){ drive.saveConfig(body.get("clientId"), body.get("clientSecret"), body.get("folderId")); return ApiResp.ok("saved"); }
  @GetMapping("/google/oauth-url") ApiResp googleOauthUrl(){ return ApiResp.ok(Map.of("url", drive.buildAuthUrl())); }
  @GetMapping("/google/callback") String googleCallback(@RequestParam String code){ drive.exchangeCode(code); return "<html><body><h2>Kết nối Google Drive thành công</h2><p>Bạn có thể quay lại trang quản trị.</p></body></html>"; }
  @GetMapping("/google/files") ApiResp files(){ return ApiResp.ok(drive.listVideoFiles()); }

  @GetMapping("/pages") List<Map<String,Object>> pages(){ return jdbc.queryForList("SELECT id,page_id,page_name,enabled,created_at,updated_at FROM facebook_pages ORDER BY id DESC"); }
  @PostMapping("/pages") ApiResp savePage(@RequestBody PageReq r){
    jdbc.update("INSERT INTO facebook_pages(page_id,page_name,page_token,enabled,updated_at) VALUES(?,?,?,?,NOW()) ON CONFLICT(page_id) DO UPDATE SET page_name=EXCLUDED.page_name,page_token=EXCLUDED.page_token,enabled=EXCLUDED.enabled,updated_at=NOW()", r.pageId(), r.pageName(), r.pageToken(), r.enabled()==null || r.enabled());
    return ApiResp.ok("saved");
  }
  @DeleteMapping("/pages/{pageId}") ApiResp delPage(@PathVariable String pageId){ jdbc.update("DELETE FROM facebook_pages WHERE page_id=?", pageId); return ApiResp.ok("deleted"); }

  @GetMapping("/scheduler") Map<String,Object> scheduler(){ return jdbc.queryForMap("SELECT reels_enabled,videos_enabled,interval_minutes,caption,last_reels_run_at,last_videos_run_at FROM scheduler_config WHERE id=1"); }
  @PostMapping("/scheduler") ApiResp saveScheduler(@RequestBody SchedulerReq r){
    jdbc.update("UPDATE scheduler_config SET reels_enabled=?,videos_enabled=?,interval_minutes=?,caption=?,updated_at=NOW() WHERE id=1", Boolean.TRUE.equals(r.reelsEnabled()), Boolean.TRUE.equals(r.videosEnabled()), r.intervalMinutes()==null?60:r.intervalMinutes(), r.caption()==null?"":r.caption());
    return ApiResp.ok("saved");
  }

  @PostMapping("/publish/manual/reel") ApiResp manualReel(@RequestBody ManualReq r){ return ApiResp.ok(pub.publishOne(r.fileId(), r.pageId(), "REEL", r.caption())); }
  @PostMapping("/publish/manual/video") ApiResp manualVideo(@RequestBody ManualReq r){ return ApiResp.ok(pub.publishOne(r.fileId(), r.pageId(), "VIDEO", r.caption())); }
  @PostMapping("/publish/run-now/reels") ApiResp runReels(){ return ApiResp.ok(pub.runAuto("REEL")); }
  @PostMapping("/publish/run-now/videos") ApiResp runVideos(){ return ApiResp.ok(pub.runAuto("VIDEO")); }
  @GetMapping("/history") List<Map<String,Object>> history(){ return jdbc.queryForList("SELECT * FROM publish_history ORDER BY id DESC LIMIT 200"); }
}

@Service
class GoogleDriveService {
  private final JdbcTemplate jdbc; private final RestTemplate http; private final ObjectMapper mapper = new ObjectMapper();
  @Value("${app.public-base-url}") String publicBaseUrl;
  GoogleDriveService(JdbcTemplate jdbc, RestTemplate http){this.jdbc=jdbc;this.http=http;}

  GoogleConfig getConfigPublic(){
    Map<String,Object> m=jdbc.queryForMap("SELECT * FROM google_drive_config WHERE id=1");
    return new GoogleConfig((String)m.get("client_id"), mask((String)m.get("client_secret")), (String)m.get("folder_id"), (String)m.get("connected_email"), m.get("refresh_token")!=null);
  }
  private String mask(String s){ if(s==null||s.length()<8)return s; return s.substring(0,4)+"****"+s.substring(s.length()-4); }
  Map<String,Object> rawConfig(){return jdbc.queryForMap("SELECT * FROM google_drive_config WHERE id=1");}
  void saveConfig(String clientId, String clientSecret, String folderId){
    String sql="UPDATE google_drive_config SET client_id=COALESCE(NULLIF(?,''),client_id), client_secret=COALESCE(NULLIF(?,''),client_secret), folder_id=?, updated_at=NOW() WHERE id=1";
    jdbc.update(sql, clientId, clientSecret, folderId);
  }
  String redirectUri(){return publicBaseUrl + "/api/google/callback";}
  String buildAuthUrl(){
    Map<String,Object> c=rawConfig();
    String clientId=(String)c.get("client_id"); if(clientId==null||clientId.isBlank()) throw new RuntimeException("Chưa cấu hình Google Client ID");
    String scope="https://www.googleapis.com/auth/drive.readonly https://www.googleapis.com/auth/userinfo.email";
    return "https://accounts.google.com/o/oauth2/v2/auth?"+
      "client_id="+enc(clientId)+"&redirect_uri="+enc(redirectUri())+"&response_type=code&access_type=offline&prompt=consent&scope="+enc(scope);
  }
  void exchangeCode(String code){
    Map<String,Object> c=rawConfig(); String clientId=(String)c.get("client_id"), secret=(String)c.get("client_secret");
    LinkedHashMap<String,String> form=new LinkedHashMap<>(); form.put("code",code); form.put("client_id",clientId); form.put("client_secret",secret); form.put("redirect_uri",redirectUri()); form.put("grant_type","authorization_code");
    JsonNode token=postForm("https://oauth2.googleapis.com/token", form);
    String access=token.path("access_token").asText(null), refresh=token.path("refresh_token").asText(null); int expires=token.path("expires_in").asInt(3600);
    String email=null; try { JsonNode user=http.getForObject("https://www.googleapis.com/oauth2/v2/userinfo?access_token="+enc(access), JsonNode.class); email=user.path("email").asText(null);} catch(Exception ignored){}
    jdbc.update("UPDATE google_drive_config SET access_token=?, refresh_token=COALESCE(?,refresh_token), token_expires_at=?, connected_email=?, updated_at=NOW() WHERE id=1", access, refresh, Timestamp.from(Instant.now().plusSeconds(expires-60)), email);
  }
  String accessToken(){
    Map<String,Object> c=rawConfig(); Timestamp exp=(Timestamp)c.get("token_expires_at"); String access=(String)c.get("access_token");
    if(access!=null && exp!=null && exp.toInstant().isAfter(Instant.now().plusSeconds(60))) return access;
    String refresh=(String)c.get("refresh_token"); if(refresh==null) throw new RuntimeException("Google Drive chưa kết nối OAuth");
    LinkedHashMap<String,String> form=new LinkedHashMap<>(); form.put("client_id",(String)c.get("client_id")); form.put("client_secret",(String)c.get("client_secret")); form.put("refresh_token",refresh); form.put("grant_type","refresh_token");
    JsonNode token=postForm("https://oauth2.googleapis.com/token", form); access=token.path("access_token").asText(); int expires=token.path("expires_in").asInt(3600);
    jdbc.update("UPDATE google_drive_config SET access_token=?, token_expires_at=?, updated_at=NOW() WHERE id=1", access, Timestamp.from(Instant.now().plusSeconds(expires-60)));
    return access;
  }
  List<Map<String,Object>> listVideoFiles(){
    Map<String,Object> c=rawConfig(); String folderId=(String)c.get("folder_id"); if(folderId==null||folderId.isBlank()) throw new RuntimeException("Chưa cấu hình Folder ID");
    String q="'"+folderId+"' in parents and trashed=false and (mimeType contains 'video/' or name contains '.mp4')";
    String url="https://www.googleapis.com/drive/v3/files?q="+enc(q)+"&fields=files(id,name,mimeType,size,md5Checksum,createdTime,modifiedTime)&orderBy=createdTime";
    HttpHeaders h=new HttpHeaders(); h.setBearerAuth(accessToken()); ResponseEntity<JsonNode> res=http.exchange(url, HttpMethod.GET, new HttpEntity<>(h), JsonNode.class);
    List<Map<String,Object>> out=new ArrayList<>(); for(JsonNode f: res.getBody().path("files")){ out.add(mapper.convertValue(f, new TypeReference<>(){})); } return out;
  }
  File downloadFile(String fileId, String filename) {
    try {
      String url="https://www.googleapis.com/drive/v3/files/"+enc(fileId)+"?alt=media";
      HttpHeaders h=new HttpHeaders(); h.setBearerAuth(accessToken());
      ResponseEntity<byte[]> res=http.exchange(url, HttpMethod.GET, new HttpEntity<>(h), byte[].class);
      File tmp=File.createTempFile("drive-", filename==null?".mp4":"-"+filename.replaceAll("[^a-zA-Z0-9._-]","_"));
      Files.write(tmp.toPath(), Objects.requireNonNull(res.getBody())); return tmp;
    } catch(Exception e){ throw new RuntimeException("Không tải được file Drive: "+e.getMessage(), e); }
  }
  private JsonNode postForm(String url, LinkedHashMap<String,String> form){
    HttpHeaders h=new HttpHeaders(); h.setContentType(MediaType.APPLICATION_FORM_URLENCODED); StringBuilder b=new StringBuilder(); form.forEach((k,v)->{ if(!b.isEmpty()) b.append('&'); b.append(enc(k)).append('=').append(enc(v));});
    ResponseEntity<JsonNode> res=http.postForEntity(url, new HttpEntity<>(b.toString(), h), JsonNode.class); if(!res.getStatusCode().is2xxSuccessful()) throw new RuntimeException("OAuth lỗi: "+res); return res.getBody();
  }
  private static String enc(String s){return URLEncoder.encode(s==null?"":s, StandardCharsets.UTF_8);}  
}

@Service
class FacebookService {
  private final RestTemplate http; private final JdbcTemplate jdbc; private final ObjectMapper mapper=new ObjectMapper();
  private final String version="v25.0";
  FacebookService(RestTemplate http, JdbcTemplate jdbc){this.http=http;this.jdbc=jdbc;}
  Map<String,Object> page(String pageId){return jdbc.queryForMap("SELECT * FROM facebook_pages WHERE page_id=? AND enabled=true", pageId);}  
  List<Map<String,Object>> pages(){return jdbc.queryForList("SELECT * FROM facebook_pages WHERE enabled=true ORDER BY id");}
  Map<String,Object> uploadVideoPost(String pageId, File video, String caption){
    Map<String,Object> p=page(pageId); String token=(String)p.get("page_token");
    String url="https://graph.facebook.com/"+version+"/"+pageId+"/videos";
    LinkedMultiValueMapLite body=new LinkedMultiValueMapLite(); body.add("access_token", token); body.add("description", caption==null?"":caption); body.addFile("source", video);
    return body.post(http, url);
  }
  Map<String,Object> publishReel(String pageId, File video, String caption){
    try{
      Map<String,Object> p=page(pageId); String token=(String)p.get("page_token"); String base="https://graph.facebook.com/"+version+"/"+pageId+"/video_reels";
      JsonNode start=postForm(base, Map.of("access_token",token,"upload_phase","start"));
      String videoId=start.path("video_id").asText(); String uploadUrl=start.path("upload_url").asText();
      HttpHeaders h=new HttpHeaders(); h.set("Authorization", "OAuth "+token); h.set("offset","0"); h.set("file_size", String.valueOf(video.length())); h.setContentType(MediaType.APPLICATION_OCTET_STREAM);
      byte[] bytes=Files.readAllBytes(video.toPath()); ResponseEntity<JsonNode> up=http.exchange(uploadUrl, HttpMethod.POST, new HttpEntity<>(bytes,h), JsonNode.class);
      if(!up.getStatusCode().is2xxSuccessful()) throw new RuntimeException("Upload reel lỗi: "+up);
      JsonNode finish=postForm(base, Map.of("access_token",token,"upload_phase","finish","video_id",videoId,"description",caption==null?"":caption));
      return mapper.convertValue(finish, new TypeReference<>(){});
    }catch(Exception e){throw new RuntimeException(e.getMessage(), e);}    
  }
  private JsonNode postForm(String url, Map<String,String> form){
    HttpHeaders h=new HttpHeaders(); h.setContentType(MediaType.APPLICATION_FORM_URLENCODED); StringBuilder b=new StringBuilder(); form.forEach((k,v)->{ if(!b.isEmpty()) b.append('&'); b.append(URLEncoder.encode(k,StandardCharsets.UTF_8)).append('=').append(URLEncoder.encode(v,StandardCharsets.UTF_8));});
    ResponseEntity<JsonNode> r=http.postForEntity(url, new HttpEntity<>(b.toString(),h), JsonNode.class); if(!r.getStatusCode().is2xxSuccessful()) throw new RuntimeException("Facebook lỗi: "+r); return r.getBody();
  }
}

class LinkedMultiValueMapLite {
  private final org.springframework.util.LinkedMultiValueMap<String,Object> map=new org.springframework.util.LinkedMultiValueMap<>();
  void add(String k,String v){map.add(k,v);} void addFile(String k, File f){map.add(k, new org.springframework.core.io.FileSystemResource(f));}
  Map<String,Object> post(RestTemplate http, String url){
    HttpHeaders h=new HttpHeaders(); h.setContentType(MediaType.MULTIPART_FORM_DATA);
    ResponseEntity<Map> r=http.postForEntity(url, new HttpEntity<>(map,h), Map.class); if(!r.getStatusCode().is2xxSuccessful()) throw new RuntimeException("Facebook lỗi: "+r); return r.getBody();
  }
}

@Service
class PublishService {
  private final JdbcTemplate jdbc; private final GoogleDriveService drive; private final FacebookService fb;
  PublishService(JdbcTemplate jdbc, GoogleDriveService drive, FacebookService fb){this.jdbc=jdbc;this.drive=drive;this.fb=fb;}
  Map<String,Object> publishOne(String fileId, String pageId, String type, String caption){
    List<Map<String,Object>> files=drive.listVideoFiles(); Map<String,Object> file=files.stream().filter(f->fileId.equals(f.get("id"))).findFirst().orElseThrow(()->new RuntimeException("Không tìm thấy file trên Drive"));
    String name=(String)file.get("name");
    int exists=jdbc.queryForObject("SELECT COUNT(*) FROM publish_history WHERE drive_file_id=? AND page_id=? AND publish_type=? AND status='SUCCESS'", Integer.class, fileId, pageId, type);
    if(exists>0) return Map.of("skipped", true, "reason", "File đã đăng thành công trước đó", "fileId", fileId, "pageId", pageId, "type", type);
    jdbc.update("INSERT INTO publish_history(drive_file_id,drive_file_name,page_id,publish_type,status) VALUES(?,?,?,?, 'UPLOADING') ON CONFLICT(drive_file_id,page_id,publish_type) DO UPDATE SET status='UPLOADING',error_message=NULL,updated_at=NOW()", fileId, name, pageId, type);
    File tmp=null; try{
      tmp=drive.downloadFile(fileId, name); Map<String,Object> res = "REEL".equals(type) ? fb.publishReel(pageId,tmp,caption) : fb.uploadVideoPost(pageId,tmp,caption);
      String fbId=String.valueOf(res.getOrDefault("id", res.getOrDefault("video_id", "")));
      jdbc.update("UPDATE publish_history SET status='SUCCESS', facebook_video_id=?, facebook_post_id=?, error_message=NULL, updated_at=NOW() WHERE drive_file_id=? AND page_id=? AND publish_type=?", fbId, fbId, fileId, pageId, type);
      return Map.of("skipped", false, "facebook", res);
    }catch(Exception e){ jdbc.update("UPDATE publish_history SET status='FAILED', error_message=?, updated_at=NOW() WHERE drive_file_id=? AND page_id=? AND publish_type=?", e.getMessage(), fileId, pageId, type); throw e; }
    finally{ if(tmp!=null) tmp.delete(); }
  }
  List<Map<String,Object>> runAuto(String type){
    Map<String,Object> cfg=jdbc.queryForMap("SELECT caption FROM scheduler_config WHERE id=1"); String cap=(String)cfg.get("caption");
    List<Map<String,Object>> out=new ArrayList<>(); List<Map<String,Object>> pages=fb.pages(); List<Map<String,Object>> files=drive.listVideoFiles();
    for(Map<String,Object> f: files){ for(Map<String,Object> p: pages){ try{ out.add(publishOne((String)f.get("id"),(String)p.get("page_id"),type,cap)); }catch(Exception e){ out.add(Map.of("ok",false,"file",f.get("name"),"page",p.get("page_id"),"error",e.getMessage())); } } }
    return out;
  }
  @Scheduled(fixedDelay = 60000)
  void schedule(){
    try{
      Map<String,Object> c=jdbc.queryForMap("SELECT * FROM scheduler_config WHERE id=1"); int min=((Number)c.get("interval_minutes")).intValue();
      if(Boolean.TRUE.equals(c.get("reels_enabled")) && due((Timestamp)c.get("last_reels_run_at"), min)){ runAuto("REEL"); jdbc.update("UPDATE scheduler_config SET last_reels_run_at=NOW() WHERE id=1"); }
      if(Boolean.TRUE.equals(c.get("videos_enabled")) && due((Timestamp)c.get("last_videos_run_at"), min)){ runAuto("VIDEO"); jdbc.update("UPDATE scheduler_config SET last_videos_run_at=NOW() WHERE id=1"); }
    }catch(Exception e){ System.err.println("Scheduler error: "+e.getMessage()); }
  }
  private boolean due(Timestamp t, int minutes){return t==null || t.toInstant().isBefore(Instant.now().minusSeconds(Math.max(1,minutes)*60L));}
}
