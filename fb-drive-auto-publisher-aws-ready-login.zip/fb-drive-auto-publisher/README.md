# FB Drive Auto Publisher - AWS Ready + Login

Spring Boot + React + PostgreSQL dùng để lấy video từ Google Drive và tự động đăng lên Facebook Page Reels hoặc video thường.

Bản này đã thêm đăng nhập quản trị bằng JWT.

## Tài khoản mặc định

```text
Username: admin
Password: Admin@123456
```

Sau khi đăng nhập, vào mục **Tài khoản quản trị** để đổi mật khẩu.

## Chạy trên VPS AWS RAM 1GB

Nên tạo swap trước khi build Docker:

```bash
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
free -h
```

Cài Docker:

```bash
sudo apt update
sudo apt install -y unzip curl ca-certificates
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker $USER
```

Đăng xuất SSH rồi đăng nhập lại. Sau đó upload zip lên VPS và chạy:

```bash
unzip fb-drive-auto-publisher-aws-ready-login.zip
cd fb-drive-auto-publisher
docker compose up -d --build
```

Mở web:

```text
http://IP_VPS:8089
```

## Cấu hình public URL cho Google OAuth

Trong `docker-compose.yml`, sửa dòng:

```yaml
APP_PUBLIC_BASE_URL: ${APP_PUBLIC_BASE_URL:-http://localhost:8089}
```

thành IP thật của VPS, ví dụ:

```yaml
APP_PUBLIC_BASE_URL: http://54.xx.xx.xx:8089
```

Sau đó restart:

```bash
docker compose up -d --build
```

Trong Google Cloud Console → OAuth Client → Authorized redirect URIs, thêm:

```text
http://IP_VPS:8089/api/google/callback
```

## Google OAuth scope

```text
https://www.googleapis.com/auth/drive.readonly
https://www.googleapis.com/auth/userinfo.email
```

## Facebook Page token

Dùng Page Access Token chính thức với quyền thường cần:

```text
pages_show_list
pages_read_engagement
pages_manage_posts
```

## Chống đăng trùng

Bảng `publish_history` có unique key:

```sql
UNIQUE (drive_file_id, page_id, publish_type)
```

Nếu file Drive đã đăng thành công lên cùng Page với cùng loại `REEL` hoặc `VIDEO`, scheduler sẽ bỏ qua.

## Lệnh quản trị

```bash
docker compose ps
docker compose logs -f
docker compose restart
docker compose down
```

## Mở port AWS

Security Group EC2 cần mở inbound TCP port `8089`.
