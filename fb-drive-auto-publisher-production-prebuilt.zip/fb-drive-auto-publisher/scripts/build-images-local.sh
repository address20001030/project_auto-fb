#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
echo "Build backend image..."
docker build -t fb-drive-auto-publisher-backend:prod ./backend
echo "Build frontend image..."
docker build -t fb-drive-auto-publisher-frontend:prod ./frontend
echo "Done."
