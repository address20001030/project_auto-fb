#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
mkdir -p dist
docker save fb-drive-auto-publisher-backend:prod | gzip > dist/backend-image.tar.gz
docker save fb-drive-auto-publisher-frontend:prod | gzip > dist/frontend-image.tar.gz
cp docker-compose.prod.yml dist/docker-compose.yml
echo "Exported to dist/. Upload dist/* to VPS."
