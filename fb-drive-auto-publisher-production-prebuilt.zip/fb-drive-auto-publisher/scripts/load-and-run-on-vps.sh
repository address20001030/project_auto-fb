#!/usr/bin/env bash
set -e
gunzip -c backend-image.tar.gz | docker load
gunzip -c frontend-image.tar.gz | docker load
docker compose up -d
