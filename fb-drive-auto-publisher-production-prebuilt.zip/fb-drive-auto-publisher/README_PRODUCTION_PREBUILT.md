# Production Prebuilt Deploy - VPS RAM 1GB

Bản này dùng đúng mô hình:

- Spring Boot 3 backend image
- React build sẵn trong Nginx image
- PostgreSQL
- Docker Compose
- Web public cổng `8089`

## Quan trọng

VPS RAM 1GB không nên build Maven/NPM trực tiếp. Hãy build image ở máy khỏe hơn, sau đó upload image đã export lên VPS.

## Bước A - Build ở máy local/CI

```bash
unzip fb-drive-auto-publisher-production-prebuilt.zip
cd fb-drive-auto-publisher
chmod +x scripts/*.sh
./scripts/build-images-local.sh
./scripts/export-images.sh
```

Sau đó thư mục `dist/` sẽ có:

```text
backend-image.tar.gz
frontend-image.tar.gz
docker-compose.yml
```

## Bước B - Upload lên VPS

```bash
scp dist/* ubuntu@IP_VPS:/opt/fb-drive-auto-publisher/
```

## Bước C - Chạy trên VPS

```bash
cd /opt/fb-drive-auto-publisher
chmod +x load-and-run-on-vps.sh 2>/dev/null || true
gunzip -c backend-image.tar.gz | docker load
gunzip -c frontend-image.tar.gz | docker load
docker compose up -d
```

Mở web:

```text
http://IP_VPS:8089
```

Tài khoản mặc định:

```text
admin / Admin@123456
```

## Lệnh quản lý

```bash
docker compose ps
docker compose logs -f
docker compose restart
docker compose down
```

## Nếu muốn chạy lại sau reboot

Compose đã có `restart: unless-stopped`, container sẽ tự chạy lại khi Docker khởi động.
