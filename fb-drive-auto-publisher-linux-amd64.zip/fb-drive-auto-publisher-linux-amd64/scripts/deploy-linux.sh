#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
echo "Stopping old containers..."
docker compose down || true
echo "Building images on this Linux server architecture..."
docker compose build --no-cache
echo "Starting..."
docker compose up -d
echo "Done. Open: http://SERVER_IP:8089"
docker compose ps
