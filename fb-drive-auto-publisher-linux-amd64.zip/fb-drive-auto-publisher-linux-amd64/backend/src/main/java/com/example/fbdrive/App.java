package com.example.fbdrive;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import jakarta.persistence.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.*;
import org.springframework.security.authentication.*;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.bind.annotation.*;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.*;

@SpringBootApplication
public class App {
  public static void main(String[] args){ SpringApplication.run(App.class,args); }
  @Bean PasswordEncoder passwordEncoder(){ return new BCryptPasswordEncoder(); }
  @Bean CommandLineRunner seed(UserRepo repo, PasswordEncoder pe){ return args -> {
    if(repo.findByUsername("admin").isEmpty()) repo.save(new AppUser("admin", pe.encode("Admin@123456"), "ROLE_ADMIN"));
  };}
  @Bean SecurityFilterChain filter(HttpSecurity http) throws Exception {
    http.csrf(c->c.disable()).cors(c->{}).sessionManagement(s->s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
      .authorizeHttpRequests(a->a.requestMatchers("/api/auth/**","/actuator/**").permitAll().anyRequest().permitAll());
    return http.build();
  }
}

@Entity class AppUser { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id; @Column(unique=true) public String username; public String password; public String role; public boolean enabled=true; public AppUser(){} AppUser(String u,String p,String r){username=u;password=p;role=r;} }
interface UserRepo extends JpaRepository<AppUser,Long>{ Optional<AppUser> findByUsername(String username); }

@Entity class KeyValueConfig { @Id public String k; @Column(length=5000) public String v; public KeyValueConfig(){} KeyValueConfig(String k,String v){this.k=k;this.v=v;} }
interface ConfigRepo extends JpaRepository<KeyValueConfig,String>{}

record LoginReq(String username,String password){} record LoginRes(String token,String username){}
@RestController @RequestMapping("/api/auth") class AuthController{
  private final UserRepo users; private final PasswordEncoder pe; @Value("${jwt.secret}") String secret;
  AuthController(UserRepo users,PasswordEncoder pe){this.users=users;this.pe=pe;}
  @PostMapping("/login") LoginRes login(@RequestBody LoginReq req){
    var u=users.findByUsername(req.username()).orElseThrow(()->new BadCredentialsException("Bad credentials"));
    if(!pe.matches(req.password(), u.password)) throw new BadCredentialsException("Bad credentials");
    var key=Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    String token=Jwts.builder().subject(u.username).claim("role",u.role).issuedAt(Date.from(Instant.now())).expiration(Date.from(Instant.now().plusSeconds(86400))).signWith(key).compact();
    return new LoginRes(token,u.username);
  }
}

@RestController @RequestMapping("/api/config") class ConfigController{
  private final ConfigRepo repo; ConfigController(ConfigRepo repo){this.repo=repo;}
  @GetMapping Map<String,String> all(){ var m=new LinkedHashMap<String,String>(); repo.findAll().forEach(x->m.put(x.k,x.v)); return m; }
  @PostMapping ResponseEntity<?> save(@RequestBody Map<String,String> body){ body.forEach((k,v)->repo.save(new KeyValueConfig(k,v))); return ResponseEntity.ok(Map.of("ok",true)); }
}

@RestController @RequestMapping("/api/actions") class ActionController{
  @PostMapping("manual-reel") Map<String,Object> reel(@RequestBody Map<String,Object> body){ return Map.of("ok",true,"message","Demo endpoint: manual reel queued", "input", body); }
  @PostMapping("manual-video") Map<String,Object> video(@RequestBody Map<String,Object> body){ return Map.of("ok",true,"message","Demo endpoint: manual video queued", "input", body); }
  @GetMapping("health") Map<String,Object> health(){ return Map.of("ok",true,"time",Instant.now().toString()); }
}
