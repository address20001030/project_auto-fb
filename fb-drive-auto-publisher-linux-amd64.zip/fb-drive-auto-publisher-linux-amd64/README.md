# FB Drive Auto Publisher - linux/amd64 ready source

Deploy on AWS EC2:

```bash
sudo dnf install -y docker unzip || sudo yum install -y docker unzip
sudo systemctl enable --now docker
sudo usermod -aG docker ec2-user
# logout/login again if needed
unzip fb-drive-auto-publisher-linux-amd64.zip
cd fb-drive-auto-publisher-linux-amd64
./scripts/deploy-linux.sh
```

Open: `http://IP:8089`
Login: `admin / Admin@123456`

This package builds directly on EC2, so it will not create Mac ARM images.
