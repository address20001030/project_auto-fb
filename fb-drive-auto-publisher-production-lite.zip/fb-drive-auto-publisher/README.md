# FB Drive Auto Publisher - Docker Lite

Bản đóng gói Docker cho VPS RAM thấp. Web chạy mặc định tại cổng `8089`.

## Chạy nhanh

```bash
unzip fb-drive-auto-publisher-production-lite.zip
cd fb-drive-auto-publisher
docker compose up -d --build
```

Mở:

```text
http://IP_VPS:8089
```

## VPS RAM 1GB

Nên tạo swap trước khi build lần đầu:

```bash
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
free -h
```

Sau đó build:

```bash
docker compose up -d --build
```

## Xem log

```bash
docker compose logs -f
```

## Restart

```bash
docker compose restart
```

## Dừng

```bash
docker compose down
```

## Xóa cả database

```bash
docker compose down -v
```

## Cổng

- Web: `8089`
- Backend: nội bộ Docker, không public
- PostgreSQL: nội bộ Docker, không public

## Chức năng

- Lưu cấu hình Google Drive trong DB.
- Lưu danh sách Page ID + Page Access Token trong DB.
- Tạo lịch tự động đăng Reels hoặc video post thường từ thư mục Google Drive.
- Đăng thủ công Reels.
- Đăng thủ công video post thường.

## API sử dụng

- Google Drive API chính thức.
- Meta Graph API chính thức cho Facebook Page.

Không dùng cookie/session Facebook web nội bộ.
