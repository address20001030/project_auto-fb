CREATE TABLE app_settings (
  key VARCHAR(100) PRIMARY KEY,
  value TEXT,
  updated_at TIMESTAMP NOT NULL DEFAULT now()
);
CREATE TABLE facebook_pages (
  id BIGSERIAL PRIMARY KEY,
  page_id VARCHAR(100) NOT NULL,
  page_name VARCHAR(255),
  page_token TEXT NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT now(),
  updated_at TIMESTAMP NOT NULL DEFAULT now()
);
CREATE TABLE publish_schedules (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  type VARCHAR(20) NOT NULL,
  drive_folder_id VARCHAR(255) NOT NULL,
  caption TEXT,
  cron_expression VARCHAR(100) NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  next_run_at TIMESTAMP,
  created_at TIMESTAMP NOT NULL DEFAULT now(),
  updated_at TIMESTAMP NOT NULL DEFAULT now()
);
CREATE TABLE publish_history (
  id BIGSERIAL PRIMARY KEY,
  schedule_id BIGINT,
  page_id BIGINT,
  drive_file_id VARCHAR(255),
  drive_file_name VARCHAR(500),
  type VARCHAR(20) NOT NULL,
  fb_object_id VARCHAR(255),
  status VARCHAR(20) NOT NULL,
  error_message TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX uq_published_file_page_type ON publish_history(page_id, drive_file_id, type) WHERE status = 'SUCCESS';
