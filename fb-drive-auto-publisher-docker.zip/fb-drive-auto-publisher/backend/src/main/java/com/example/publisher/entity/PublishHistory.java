package com.example.publisher.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@Entity @Table(name = "publish_history")
public class PublishHistory {
  public enum Status { SUCCESS, FAILED }
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
  private Long scheduleId;
  private Long pageId;
  private String driveFileId;
  private String driveFileName;
  @Enumerated(EnumType.STRING) private PublishSchedule.Type type;
  private String fbObjectId;
  @Enumerated(EnumType.STRING) private Status status;
  @Column(columnDefinition = "TEXT") private String errorMessage;
  private LocalDateTime createdAt;
  @PrePersist void prePersist(){ createdAt = LocalDateTime.now(); }
}
