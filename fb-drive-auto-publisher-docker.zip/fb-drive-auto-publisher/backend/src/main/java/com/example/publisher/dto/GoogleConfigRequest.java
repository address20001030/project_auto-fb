package com.example.publisher.dto;
public record GoogleConfigRequest(String clientId, String clientSecret, String refreshToken) {}
