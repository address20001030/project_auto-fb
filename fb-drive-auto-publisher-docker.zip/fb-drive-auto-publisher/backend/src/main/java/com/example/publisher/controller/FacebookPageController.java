package com.example.publisher.controller;

import com.example.publisher.dto.FacebookPageRequest;
import com.example.publisher.entity.FacebookPage;
import com.example.publisher.repo.FacebookPageRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController @RequestMapping("/api/pages") @RequiredArgsConstructor
public class FacebookPageController {
  private final FacebookPageRepository repo;
  @GetMapping public List<FacebookPage> list(){ return repo.findAll(); }
  @PostMapping public FacebookPage create(@RequestBody FacebookPageRequest req){
    return repo.save(FacebookPage.builder().pageId(req.pageId()).pageName(req.pageName()).pageToken(req.pageToken()).enabled(req.enabled()).build());
  }
  @PutMapping("/{id}") public FacebookPage update(@PathVariable Long id, @RequestBody FacebookPageRequest req){
    FacebookPage p = repo.findById(id).orElseThrow();
    p.setPageId(req.pageId()); p.setPageName(req.pageName()); p.setPageToken(req.pageToken()); p.setEnabled(req.enabled());
    return repo.save(p);
  }
  @DeleteMapping("/{id}") public void delete(@PathVariable Long id){ repo.deleteById(id); }
}
