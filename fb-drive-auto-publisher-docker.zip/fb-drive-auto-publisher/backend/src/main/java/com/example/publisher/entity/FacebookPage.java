package com.example.publisher.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@Entity @Table(name = "facebook_pages")
public class FacebookPage {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
  private String pageId;
  private String pageName;
  @Column(columnDefinition = "TEXT") private String pageToken;
  private boolean enabled = true;
  private LocalDateTime createdAt;
  private LocalDateTime updatedAt;
  @PrePersist void prePersist(){ createdAt = LocalDateTime.now(); updatedAt = createdAt; }
  @PreUpdate void preUpdate(){ updatedAt = LocalDateTime.now(); }
}
