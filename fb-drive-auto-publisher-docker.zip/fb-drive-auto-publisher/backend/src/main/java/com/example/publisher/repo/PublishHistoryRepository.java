package com.example.publisher.repo;
import com.example.publisher.entity.PublishHistory;
import org.springframework.data.jpa.repository.JpaRepository;
public interface PublishHistoryRepository extends JpaRepository<PublishHistory, Long> {
  boolean existsByPageIdAndDriveFileIdAndTypeAndStatus(Long pageId, String driveFileId, com.example.publisher.entity.PublishSchedule.Type type, PublishHistory.Status status);
}
