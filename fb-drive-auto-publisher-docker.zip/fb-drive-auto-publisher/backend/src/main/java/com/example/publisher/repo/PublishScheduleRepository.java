package com.example.publisher.repo;
import com.example.publisher.entity.PublishSchedule;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDateTime;
import java.util.List;
public interface PublishScheduleRepository extends JpaRepository<PublishSchedule, Long> {
  List<PublishSchedule> findByEnabledTrueAndNextRunAtLessThanEqual(LocalDateTime now);
}
