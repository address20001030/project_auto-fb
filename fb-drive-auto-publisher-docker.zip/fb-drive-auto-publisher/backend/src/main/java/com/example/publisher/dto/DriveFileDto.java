package com.example.publisher.dto;
public record DriveFileDto(String id, String name, String mimeType) {}
