package com.example.publisher.scheduler;

import com.example.publisher.entity.PublishSchedule;
import com.example.publisher.repo.PublishScheduleRepository;
import com.example.publisher.service.PublishService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.support.CronExpression;
import org.springframework.stereotype.Component;
import java.time.LocalDateTime;

@Component @RequiredArgsConstructor
public class AutoPublishScheduler {
  private final PublishScheduleRepository scheduleRepo;
  private final PublishService publishService;

  @Scheduled(fixedDelayString = "${app.scheduler.poll-ms:30000}")
  public void tick() {
    LocalDateTime now = LocalDateTime.now();
    for (PublishSchedule schedule : scheduleRepo.findByEnabledTrueAndNextRunAtLessThanEqual(now)) {
      try {
        publishService.runSchedule(schedule);
      } catch (Exception e) {
        System.err.println("Schedule lỗi id=" + schedule.getId() + ": " + e.getMessage());
      } finally {
        schedule.setNextRunAt(nextRun(schedule.getCronExpression(), LocalDateTime.now()));
        scheduleRepo.save(schedule);
      }
    }
  }

  public static LocalDateTime nextRun(String cron, LocalDateTime from) {
    return CronExpression.parse(cron).next(from);
  }
}
