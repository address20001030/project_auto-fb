package com.example.publisher.controller;

import com.example.publisher.dto.GoogleConfigRequest;
import com.example.publisher.service.SettingService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController @RequestMapping("/api/settings") @RequiredArgsConstructor
public class SettingsController {
  private final SettingService service;
  @GetMapping public Map<String,String> all(){ return service.all(); }
  @PostMapping("/google") public Map<String,Object> saveGoogle(@RequestBody GoogleConfigRequest req){ service.saveGoogleConfig(req); return Map.of("success", true); }
}
