package com.example.publisher.service;

import com.example.publisher.dto.DriveFileDto;
import com.example.publisher.entity.*;
import com.example.publisher.repo.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

@Service @RequiredArgsConstructor
public class PublishService {
  private final FacebookPageRepository pageRepo;
  private final PublishHistoryRepository historyRepo;
  private final GoogleDriveService driveService;
  private final FacebookService facebookService;

  public void runSchedule(PublishSchedule schedule) throws Exception {
    List<FacebookPage> pages = pageRepo.findByEnabledTrue();
    List<DriveFileDto> files = driveService.listVideoFiles(schedule.getDriveFolderId());
    for (FacebookPage page : pages) {
      DriveFileDto next = files.stream()
          .filter(f -> !historyRepo.existsByPageIdAndDriveFileIdAndTypeAndStatus(page.getId(), f.id(), schedule.getType(), PublishHistory.Status.SUCCESS))
          .findFirst().orElse(null);
      if (next == null) continue;
      publishOne(schedule.getId(), page, schedule.getType(), next.id(), next.name(), schedule.getCaption());
    }
  }

  public PublishHistory manualPublish(Long pageDbId, PublishSchedule.Type type, String driveFileId, String caption) throws Exception {
    FacebookPage page = pageRepo.findById(pageDbId).orElseThrow(() -> new IllegalArgumentException("Không tìm thấy page DB id=" + pageDbId));
    return publishOne(null, page, type, driveFileId, driveFileId + ".mp4", caption);
  }

  private PublishHistory publishOne(Long scheduleId, FacebookPage page, PublishSchedule.Type type, String driveFileId, String fileName, String caption) throws Exception {
    Path tmp = null;
    try {
      tmp = driveService.downloadFile(driveFileId, fileName);
      String fbId = type == PublishSchedule.Type.REELS
          ? facebookService.publishReel(page, tmp, caption)
          : facebookService.publishVideoPost(page, tmp, caption);
      return historyRepo.save(PublishHistory.builder().scheduleId(scheduleId).pageId(page.getId()).driveFileId(driveFileId).driveFileName(fileName).type(type).fbObjectId(fbId).status(PublishHistory.Status.SUCCESS).build());
    } catch (Exception e) {
      historyRepo.save(PublishHistory.builder().scheduleId(scheduleId).pageId(page.getId()).driveFileId(driveFileId).driveFileName(fileName).type(type).status(PublishHistory.Status.FAILED).errorMessage(e.getMessage()).build());
      throw e;
    } finally {
      if (tmp != null) Files.deleteIfExists(tmp);
    }
  }
}
