package com.example.publisher.service;

import com.example.publisher.dto.GoogleConfigRequest;
import com.example.publisher.entity.AppSetting;
import com.example.publisher.repo.AppSettingRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.stream.Collectors;

@Service @RequiredArgsConstructor
public class SettingService {
  private final AppSettingRepository repo;
  public void saveGoogleConfig(GoogleConfigRequest req) {
    save("google.clientId", req.clientId());
    save("google.clientSecret", req.clientSecret());
    save("google.refreshToken", req.refreshToken());
  }
  public Map<String,String> all() { return repo.findAll().stream().collect(Collectors.toMap(AppSetting::getKey, s -> s.getValue() == null ? "" : s.getValue())); }
  public String get(String key) { return repo.findById(key).map(AppSetting::getValue).orElseThrow(() -> new IllegalStateException("Thiếu cấu hình: " + key)); }
  private void save(String key, String value) { repo.save(AppSetting.builder().key(key).value(value).build()); }
}
