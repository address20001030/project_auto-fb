package com.example.publisher.service;

import com.example.publisher.dto.DriveFileDto;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.FileContent;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.model.FileList;
import com.google.auth.http.HttpCredentialsAdapter;
import com.google.auth.oauth2.AccessToken;
import com.google.auth.oauth2.UserCredentials;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

@Service @RequiredArgsConstructor
public class GoogleDriveService {
  private final SettingService settings;

  private Drive drive() throws Exception {
    UserCredentials credentials = UserCredentials.newBuilder()
        .setClientId(settings.get("google.clientId"))
        .setClientSecret(settings.get("google.clientSecret"))
        .setRefreshToken(settings.get("google.refreshToken"))
        .build();
    credentials.refreshIfExpired();
    HttpTransport httpTransport = GoogleNetHttpTransport.newTrustedTransport();
    return new Drive.Builder(httpTransport, GsonFactory.getDefaultInstance(), new HttpCredentialsAdapter(credentials))
        .setApplicationName("fb-drive-auto-publisher")
        .build();
  }

  public List<DriveFileDto> listVideoFiles(String folderId) throws Exception {
    String q = "'" + folderId + "' in parents and trashed=false and mimeType contains 'video/'";
    FileList result = drive().files().list()
        .setQ(q)
        .setFields("files(id,name,mimeType,createdTime)")
        .setOrderBy("createdTime asc")
        .setPageSize(50)
        .execute();
    return result.getFiles().stream().map(f -> new DriveFileDto(f.getId(), f.getName(), f.getMimeType())).toList();
  }

  public Path downloadFile(String fileId, String fileName) throws Exception {
    Path temp = Files.createTempFile("drive-video-", "-" + fileName.replaceAll("[^a-zA-Z0-9._-]", "_"));
    try (FileOutputStream out = new FileOutputStream(temp.toFile())) {
      drive().files().get(fileId).executeMediaAndDownloadTo(out);
    }
    return temp;
  }
}
