package com.example.publisher.controller;

import com.example.publisher.dto.*;
import com.example.publisher.entity.PublishHistory;
import com.example.publisher.repo.PublishHistoryRepository;
import com.example.publisher.service.GoogleDriveService;
import com.example.publisher.service.PublishService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController @RequestMapping("/api/publish") @RequiredArgsConstructor
public class PublishController {
  private final GoogleDriveService driveService;
  private final PublishService publishService;
  private final PublishHistoryRepository historyRepo;
  @GetMapping("/drive-files") public List<DriveFileDto> files(@RequestParam String folderId) throws Exception { return driveService.listVideoFiles(folderId); }
  @PostMapping("/manual") public PublishHistory manual(@RequestBody ManualPublishRequest req) throws Exception { return publishService.manualPublish(req.pageDbId(), req.type(), req.driveFileId(), req.caption()); }
  @GetMapping("/history") public List<PublishHistory> history(){ return historyRepo.findAll(); }
}
