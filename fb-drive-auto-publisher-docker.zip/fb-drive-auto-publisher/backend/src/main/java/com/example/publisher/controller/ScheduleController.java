package com.example.publisher.controller;

import com.example.publisher.dto.ScheduleRequest;
import com.example.publisher.entity.PublishSchedule;
import com.example.publisher.repo.PublishScheduleRepository;
import com.example.publisher.scheduler.AutoPublishScheduler;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.List;

@RestController @RequestMapping("/api/schedules") @RequiredArgsConstructor
public class ScheduleController {
  private final PublishScheduleRepository repo;
  @GetMapping public List<PublishSchedule> list(){ return repo.findAll(); }
  @PostMapping public PublishSchedule create(@RequestBody ScheduleRequest req){
    PublishSchedule s = PublishSchedule.builder().name(req.name()).type(req.type()).driveFolderId(req.driveFolderId()).caption(req.caption()).cronExpression(req.cronExpression()).enabled(req.enabled()).build();
    s.setNextRunAt(AutoPublishScheduler.nextRun(req.cronExpression(), LocalDateTime.now()));
    return repo.save(s);
  }
  @PutMapping("/{id}") public PublishSchedule update(@PathVariable Long id, @RequestBody ScheduleRequest req){
    PublishSchedule s = repo.findById(id).orElseThrow();
    s.setName(req.name()); s.setType(req.type()); s.setDriveFolderId(req.driveFolderId()); s.setCaption(req.caption()); s.setCronExpression(req.cronExpression()); s.setEnabled(req.enabled());
    s.setNextRunAt(AutoPublishScheduler.nextRun(req.cronExpression(), LocalDateTime.now()));
    return repo.save(s);
  }
  @DeleteMapping("/{id}") public void delete(@PathVariable Long id){ repo.deleteById(id); }
}
