package com.example.publisher.repo;
import com.example.publisher.entity.FacebookPage;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface FacebookPageRepository extends JpaRepository<FacebookPage, Long> { List<FacebookPage> findByEnabledTrue(); }
