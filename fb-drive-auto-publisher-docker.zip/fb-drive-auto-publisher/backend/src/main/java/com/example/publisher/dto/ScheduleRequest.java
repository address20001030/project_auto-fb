package com.example.publisher.dto;
import com.example.publisher.entity.PublishSchedule;
public record ScheduleRequest(String name, PublishSchedule.Type type, String driveFolderId, String caption, String cronExpression, boolean enabled) {}
