package com.example.publisher.dto;
import com.example.publisher.entity.PublishSchedule;
public record ManualPublishRequest(Long pageDbId, PublishSchedule.Type type, String driveFileId, String caption) {}
