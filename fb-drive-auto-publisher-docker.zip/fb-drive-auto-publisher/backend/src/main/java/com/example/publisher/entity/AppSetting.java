package com.example.publisher.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@Entity @Table(name = "app_settings")
public class AppSetting {
  @Id @Column(name = "key") private String key;
  @Column(columnDefinition = "TEXT") private String value;
  private LocalDateTime updatedAt;
  @PrePersist @PreUpdate void touch(){ updatedAt = LocalDateTime.now(); }
}
