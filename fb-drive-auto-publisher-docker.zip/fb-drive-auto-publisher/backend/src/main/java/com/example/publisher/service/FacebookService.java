package com.example.publisher.service;

import com.example.publisher.entity.FacebookPage;
import com.example.publisher.entity.PublishSchedule;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

@Service @RequiredArgsConstructor
public class FacebookService {
  private static final String GRAPH_VERSION = "v25.0";
  private final ObjectMapper mapper = new ObjectMapper();
  private final RestTemplate restTemplate = new RestTemplate();

  public String publishVideoPost(FacebookPage page, Path videoPath, String caption) throws Exception {
    String url = "https://graph.facebook.com/" + GRAPH_VERSION + "/" + page.getPageId() + "/videos";
    MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
    body.add("access_token", page.getPageToken());
    body.add("description", caption == null ? "" : caption);
    body.add("published", "true");
    body.add("source", new FileSystemResource(videoPath.toFile()));
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.MULTIPART_FORM_DATA);
    JsonNode json = post(url, new HttpEntity<>(body, headers));
    return json.path("id").asText();
  }

  public String publishReel(FacebookPage page, Path videoPath, String caption) throws Exception {
    String startUrl = "https://graph.facebook.com/" + GRAPH_VERSION + "/" + page.getPageId() + "/video_reels";
    MultiValueMap<String, String> startBody = new LinkedMultiValueMap<>();
    startBody.add("access_token", page.getPageToken());
    startBody.add("upload_phase", "start");
    JsonNode start = postForm(startUrl, startBody);
    String videoId = start.path("video_id").asText();
    String uploadUrl = start.path("upload_url").asText();
    if (videoId.isBlank() || uploadUrl.isBlank()) throw new IllegalStateException("Không lấy được video_id/upload_url từ Meta: " + start);

    HttpHeaders uploadHeaders = new HttpHeaders();
    uploadHeaders.add("Authorization", "OAuth " + page.getPageToken());
    uploadHeaders.add("offset", "0");
    uploadHeaders.add("file_size", String.valueOf(Files.size(videoPath)));
    uploadHeaders.setContentType(MediaType.APPLICATION_OCTET_STREAM);
    ResponseEntity<String> uploadResp = restTemplate.exchange(uploadUrl, HttpMethod.POST, new HttpEntity<>(Files.readAllBytes(videoPath), uploadHeaders), String.class);
    if (!uploadResp.getStatusCode().is2xxSuccessful()) throw new RuntimeException("Upload reel lỗi: " + uploadResp.getBody());

    MultiValueMap<String, String> finishBody = new LinkedMultiValueMap<>();
    finishBody.add("access_token", page.getPageToken());
    finishBody.add("upload_phase", "finish");
    finishBody.add("video_id", videoId);
    finishBody.add("description", caption == null ? "" : caption);
    JsonNode finish = postForm(startUrl, finishBody);
    return finish.path("post_id").asText(videoId);
  }

  private JsonNode postForm(String url, MultiValueMap<String, String> body) throws Exception {
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
    return post(url, new HttpEntity<>(body, headers));
  }
  private JsonNode post(String url, HttpEntity<?> entity) throws Exception {
    ResponseEntity<String> resp = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
    JsonNode json = mapper.readTree(resp.getBody());
    if (!resp.getStatusCode().is2xxSuccessful() || json.has("error")) throw new RuntimeException("Meta API lỗi: " + json);
    return json;
  }
}
