package com.example.publisher.dto;
public record FacebookPageRequest(String pageId, String pageName, String pageToken, boolean enabled) {}
