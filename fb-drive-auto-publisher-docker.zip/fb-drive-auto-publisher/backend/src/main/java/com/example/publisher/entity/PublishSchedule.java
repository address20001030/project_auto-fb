package com.example.publisher.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@Entity @Table(name = "publish_schedules")
public class PublishSchedule {
  public enum Type { REELS, VIDEO_POST }
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
  private String name;
  @Enumerated(EnumType.STRING) private Type type;
  private String driveFolderId;
  @Column(columnDefinition = "TEXT") private String caption;
  private String cronExpression;
  private boolean enabled = true;
  private LocalDateTime nextRunAt;
  private LocalDateTime createdAt;
  private LocalDateTime updatedAt;
  @PrePersist void prePersist(){ createdAt = LocalDateTime.now(); updatedAt = createdAt; }
  @PreUpdate void preUpdate(){ updatedAt = LocalDateTime.now(); }
}
