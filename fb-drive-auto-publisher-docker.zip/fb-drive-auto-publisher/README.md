# FB Drive Auto Publisher

Project mẫu chạy bằng Docker Compose trên VPS.

## Chức năng

- Spring Boot backend + PostgreSQL.
- ReactJS frontend.
- Web chạy mặc định tại cổng `8089`.
- Lưu cấu hình Google Drive trong database, không hard-code trong env.
- Lưu danh sách Facebook Page ID + Page Access Token trong database.
- Tự động lấy video từ thư mục Google Drive và đăng lên Facebook Page Reels theo lịch cấu hình.
- Tự động đăng video bài viết thường lên Page theo lịch cấu hình.
- Đăng thủ công Reels.
- Đăng thủ công video bài viết thường.

## Chạy trên VPS

Yêu cầu VPS đã cài Docker và Docker Compose.

```bash
unzip fb-drive-auto-publisher-docker.zip
cd fb-drive-auto-publisher
docker compose up -d --build
```

Mở web:

```text
http://IP_VPS:8089
```

Xem log:

```bash
docker compose logs -f backend
docker compose logs -f frontend
```

Dừng project:

```bash
docker compose down
```

Xóa cả database volume:

```bash
docker compose down -v
```

## Database mặc định

PostgreSQL chạy trong Docker:

```text
DB: fb_publisher
USER: postgres
PASSWORD: postgres
```

Backend tự chạy Flyway migration khi start.

## Lưu ý Facebook API

Project dùng API chính thức cho Facebook Page:

- Video thường: `/{page-id}/videos`
- Reels: `/{page-id}/video_reels`

Bạn cần Page Access Token hợp lệ, có quyền phù hợp như `pages_manage_posts`, `pages_read_engagement`, `pages_show_list`.

Graph API chính thức không hỗ trợ tự động đăng video lên profile cá nhân.

## Lưu ý Google Drive

Cấu hình Google Drive được nhập trên web và lưu DB. Thư mục Drive cần cấp quyền cho service account hoặc OAuth credential mà bạn nhập.
