import React, {useEffect, useState} from 'react';
import {createRoot} from 'react-dom/client';
import axios from 'axios';
import './style.css';

const api = axios.create({baseURL: '/api'});

function App(){
  const [pages,setPages]=useState([]); const [schedules,setSchedules]=useState([]); const [history,setHistory]=useState([]);
  const [google,setGoogle]=useState({clientId:'',clientSecret:'',refreshToken:''});
  const [page,setPage]=useState({pageId:'',pageName:'',pageToken:'',enabled:true});
  const [sch,setSch]=useState({name:'Reels mỗi ngày',type:'REELS',driveFolderId:'',caption:'',cronExpression:'0 0 9 * * *',enabled:true});
  const [manual,setManual]=useState({pageDbId:'',type:'REELS',driveFileId:'',caption:''});
  const [folderId,setFolderId]=useState(''); const [files,setFiles]=useState([]); const [msg,setMsg]=useState('');
  const load=()=>{api.get('/pages').then(r=>setPages(r.data)); api.get('/schedules').then(r=>setSchedules(r.data)); api.get('/publish/history').then(r=>setHistory(r.data));};
  useEffect(load,[]);
  const submit=async(fn)=>{try{setMsg('Đang xử lý...'); await fn(); setMsg('Thành công'); load();}catch(e){setMsg(e.response?.data?.message || e.message)}};
  return <div className="wrap"><h1>Facebook Page Publisher</h1><p className="note">Dùng Graph API chính thức: Page video, Page Reels và Google Drive API.</p><div className="grid">
    <section><h2>1. Cấu hình Google Drive</h2><input placeholder="Google Client ID" value={google.clientId} onChange={e=>setGoogle({...google,clientId:e.target.value})}/><input placeholder="Google Client Secret" value={google.clientSecret} onChange={e=>setGoogle({...google,clientSecret:e.target.value})}/><textarea placeholder="Google Refresh Token" value={google.refreshToken} onChange={e=>setGoogle({...google,refreshToken:e.target.value})}/><button onClick={()=>submit(()=>api.post('/settings/google',google))}>Lưu Google</button></section>
    <section><h2>2. Danh sách Page</h2><input placeholder="Page ID" value={page.pageId} onChange={e=>setPage({...page,pageId:e.target.value})}/><input placeholder="Page Name" value={page.pageName} onChange={e=>setPage({...page,pageName:e.target.value})}/><textarea placeholder="Page Access Token" value={page.pageToken} onChange={e=>setPage({...page,pageToken:e.target.value})}/><label><input type="checkbox" checked={page.enabled} onChange={e=>setPage({...page,enabled:e.target.checked})}/> Enabled</label><button onClick={()=>submit(()=>api.post('/pages',page))}>Thêm Page</button><ul>{pages.map(p=><li key={p.id}>{p.pageName || p.pageId} - {p.enabled?'ON':'OFF'}</li>)}</ul></section>
    <section><h2>3. Lịch tự động</h2><input placeholder="Tên lịch" value={sch.name} onChange={e=>setSch({...sch,name:e.target.value})}/><select value={sch.type} onChange={e=>setSch({...sch,type:e.target.value})}><option value="REELS">Reels</option><option value="VIDEO_POST">Bài video thường</option></select><input placeholder="Google Drive Folder ID" value={sch.driveFolderId} onChange={e=>setSch({...sch,driveFolderId:e.target.value})}/><textarea placeholder="Caption" value={sch.caption} onChange={e=>setSch({...sch,caption:e.target.value})}/><input placeholder="Cron: 0 0 9 * * *" value={sch.cronExpression} onChange={e=>setSch({...sch,cronExpression:e.target.value})}/><label><input type="checkbox" checked={sch.enabled} onChange={e=>setSch({...sch,enabled:e.target.checked})}/> Enabled</label><button onClick={()=>submit(()=>api.post('/schedules',sch))}>Tạo lịch</button><ul>{schedules.map(s=><li key={s.id}>{s.name} - {s.type} - next: {s.nextRunAt}</li>)}</ul></section>
    <section><h2>4. Đăng thủ công</h2><select value={manual.pageDbId} onChange={e=>setManual({...manual,pageDbId:e.target.value})}><option value="">Chọn Page</option>{pages.map(p=><option key={p.id} value={p.id}>{p.pageName || p.pageId}</option>)}</select><select value={manual.type} onChange={e=>setManual({...manual,type:e.target.value})}><option value="REELS">Reels</option><option value="VIDEO_POST">Bài video thường</option></select><input placeholder="Drive File ID" value={manual.driveFileId} onChange={e=>setManual({...manual,driveFileId:e.target.value})}/><textarea placeholder="Caption" value={manual.caption} onChange={e=>setManual({...manual,caption:e.target.value})}/><button onClick={()=>submit(()=>api.post('/publish/manual',manual))}>Đăng ngay</button><hr/><input placeholder="Folder ID để xem file" value={folderId} onChange={e=>setFolderId(e.target.value)}/><button onClick={()=>submit(async()=>setFiles((await api.get('/publish/drive-files',{params:{folderId}})).data))}>Load file Drive</button><ul>{files.map(f=><li key={f.id}><b>{f.name}</b><br/><code>{f.id}</code></li>)}</ul></section>
  </div><h2>Lịch sử</h2><pre>{JSON.stringify(history.slice(-20).reverse(), null, 2)}</pre><p className="msg">{msg}</p></div>
}

createRoot(document.getElementById('root')).render(<App/>);
